# Open Orders UI - Flutter Project

This Flutter application replicates an "Open Orders" page similar to a stock trading dashboard.

## Features

- AppBar with Download button and Cancel All button
- Filter Inputs: Client selection, Stock search
- Selected Filters: Chips for active filters
- DataTable showing orders
- Pagination Controls: Previous, Next buttons
- Responsive Design: Scrollable table

## Getting Started

### Installation

```bash
flutter create open_orders_ui
cd open_orders_ui
```

Replace the `lib/main.dart` with the provided `main.dart`.

### Running the App

```bash
flutter run
```

## Project Structure

```
lib/
 └── main.dart
```

## Author

- Developed by [Your Name]

## License

This project is licensed under the MIT License.

---